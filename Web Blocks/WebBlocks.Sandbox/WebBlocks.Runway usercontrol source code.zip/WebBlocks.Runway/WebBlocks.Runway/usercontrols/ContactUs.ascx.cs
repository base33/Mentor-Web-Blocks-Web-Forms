﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebBlocks.Runway.usercontrols
{
    public partial class ContactUs : System.Web.UI.UserControl
    {
        public string To { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public bool Active { get; set; }

        public string SuccessMessage { get; set; }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                plcSend.Visible = true;
                plcSuccess.Visible = false;
            }
        }

        protected void btnSubmit_OnClick(object sender, EventArgs e)
        {
            if (Active)
            {
                plcSend.Visible = false;
                plcSuccess.Visible = true;
                string message = "";
                message += "Name: " + txtName.Text + "<br/>";
                message += "Email: " + txtEmail.Text + "<br/>";
                message += "Message:<br/>" + txtMessage.Text;
                umbraco.library.SendMail(From, To, Subject, message, true);
            }
        }
    }
}